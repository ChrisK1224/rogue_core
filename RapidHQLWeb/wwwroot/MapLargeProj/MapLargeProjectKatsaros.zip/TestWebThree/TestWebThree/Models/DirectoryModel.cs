﻿using Microsoft.AspNetCore.Http;
using rogueCore.rogueUIV3.web;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace TestWebThree.Models
{
    public class DirectoryModel
    {
        string rootPath { get; set; }
        const string selectDirCommand =  "DirectoryClick";
        const string addDirCommand = "AddDirectoryClick";
        const string dirFile = "file";
        const string dirFolder = "folder";
        Dictionary<string, Action<string,string>> uploadDirType = new Dictionary<string, Action<string, string>>();
        Dictionary<string, Func<string, string>> selectDirType = new Dictionary<string, Func<string, string>>();
        public string sectionQry { get; private set; }
        //*This is a query using made from scratch database called HQL
        public string directoryQuery { get { return "FROM \"HEADERDIV\" SELECT \"groupbox\" AS CONTROLNAME,\"child\" AS PARENTRELATION  SNIPPET UI_LABEL[@PARENT_JOIN = \"HEADERDIV\", @UI_FONTSIZE = \"30\", @UI_TEXT = \"\"File Explorer\"\"];  FROM EXECUTE(UI_FOLDER_EXPLORER, " + rootPath + ", " + selectDirCommand + ") AS FILEEXPLORER JOIN TO HEADERDIV"; } }
        public DirectoryModel(string rootPath)
        {
            Load(rootPath);
            SelectFolder(rootPath);
        }
        public DirectoryModel(string rootPath, string path)
        {
            Load(rootPath);
            FileAttributes attr = File.GetAttributes(path);
            if (attr.HasFlag(FileAttributes.Directory))
                SelectFolder(path);
            else
            {
                if (File.Exists(path))
                {
                    SelectFile(path);
                }
                else
                {
                    SelectFile(rootPath + Path.DirectorySeparatorChar + "testme" + Path.DirectorySeparatorChar + "find.txt");
                }
            }
        }
        void Load(string rootPath)
        {
            this.rootPath = rootPath;
            uploadDirType.Add(dirFile, AddFile);
            uploadDirType.Add(dirFolder, AddFolder);
            selectDirType.Add(dirFile, SelectFile);
            selectDirType.Add(dirFolder, SelectFolder);
        }
        //*Handles clicking of Files and Folders from the Web Page
        public void RunClickEvent(string clickParam)
        {
            string[] clickParams = clickParam.Split(";");
            switch (clickParams[0])
            {
                case addDirCommand:
                    uploadDirType[clickParams[1].ToLower()](clickParams[2], clickParams[3]);
                    break;
                case selectDirCommand:
                    selectDirType[clickParams[1].ToLower()](clickParams[2]);
                    break;
            }
        }
        void AddFile(string filePath, string newFileName)
        {
            File.Create(filePath);
        }
        void AddFolder(string folderPath, string newFolderName)
        {
            Directory.CreateDirectory(folderPath + "\\" + newFolderName.Replace("\\","").Replace("/",""));
        }
        //*This creates the HQL QUery to refresh the File Info Section of the Web Page
        string SelectFile(string filePath)
        {
            FileInfo fil = new FileInfo(filePath);
            string fileQuery = "FROM \"MYDIV\" SELECT \"groupbox\" AS CONTROLNAME,\"child\" AS PARENTRELATION SNIPPET UI_LABEL[@PARENT_JOIN = \"MYDIV\", @UI_FONTSIZE = \"30\", @UI_TEXT = \"\"Directory Info\"\"];"
               + " FROM \"DIV\" JOIN TO MYDIV SELECT \"groupbox\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " FROM \"DIRLABEL\" JOIN TO DIV SELECT \"label\" AS CONTROLNAME, \"child\" as PARENTRELATION FROM \"dirLblID\"  JOIN TO DIRLABEL SELECT \"text\" AS ATTRIBUTETYPE,\"attribute\" AS PARENTRELATION, \"" + filePath + "\" AS ATTRIBUTEVALUE  FROM \"PATHID\" JOIN TO DIRLABEL SELECT \"idname\" AS ATTRIBUTETYPE, \"attribute\" AS PARENTRELATION, \"currDirectory\" as ATTRIBUTEVALUE FROM \"hidethis\" JOIN TO DIRLABEL SELECT \"cssdisplay\" AS ATTRIBUTETYPE, \"none\" AS ATTRIBUTEVALUE, \"attribute\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"File Name : " + fil.Name + "\"\"]; FROM \"NameBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"File Path : " + fil.FullName.Replace(rootPath, "~") + "\"\"]; FROM \"PathBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Extension : " + fil.Extension + "\"\"]; FROM \"ExtBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"File Size : " + fil.Length.ToString() + " bytes \"\"]; FROM \"SizeBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Creation Date : " + fil.CreationTime.ToShortDateString() + "\"\"]; FROM \"DateBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + "  FROM \"CONTENTBOX\"  SELECT \"textarea\"  AS CONTROLNAME, \"child\"  AS PARENTRELATION FROM \"CONTENTTEXT\" JOIN TO CONTENTBOX SELECT \"text\"  AS ATTRIBUTETYPE, \"" + ReadChars(fil.FullName, 1000) + "\"  AS ATTRIBUTEVALUE, \"attribute\"  AS PARENTRELATION FROM \"CONTENTWIDTH\" JOIN TO CONTENTBOX SELECT \"widthpixels\"  AS ATTRIBUTETYPE, \"500\" AS ATTRIBUTEVALUE, \"attribute\"  AS PARENTRELATION FROM \"CONTENTHEIGHT\" JOIN TO CONTENTBOX SELECT \"heightpixels\"  AS ATTRIBUTETYPE, \"250\"  AS ATTRIBUTEVALUE, \"attribute\"  AS PARENTRELATION  FROM \"txtAreaBreak\"  SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION  "
               + " FROM \"DOWNLOADBTN\" SELECT \"button\" as CONTROLNAME, \"CHILD\" AS PARENTRELATION FROM \"BTNNAME\" JOIN TO DOWNLOADBTN SELECT \"text\" AS ATTRIBUTETYPE, \"attribute\" as PARENTRELATION, \"Download\" AS ATTRIBUTEVALUE FROM \"BTNID\" JOIN TO DOWNLOADBTN SELECT \"mouseclickcustom\" AS ATTRIBUTETYPE, \"attribute\" as PARENTRELATION, \"exported()\" AS ATTRIBUTEVALUE ";
            sectionQry = new UIWebSection(fileQuery).AsJson;
            return "";
        }
        static string ReadChars(string filename, int count)
        {
            using (var stream = File.OpenRead(filename))
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                char[] buffer = new char[count];
                int n = reader.ReadBlock(buffer, 0, count);

                char[] result = new char[n];

                Array.Copy(buffer, result, n);
                
                return new string(result).Replace("\"", "\"\"").Replace("FROM","FRO");
            }
        }
        //*This creates the HQL QUery to refersh the Folder Info Section of the Web Page
        string SelectFolder(string folderPath)
        {
            DirectoryInfo fol = new DirectoryInfo(folderPath);
            string fileQuery = "FROM \"MYDIV\" SELECT \"groupbox\" AS CONTROLNAME,\"child\" AS PARENTRELATION SNIPPET UI_LABEL[@PARENT_JOIN = \"MYDIV\", @UI_FONTSIZE = \"30\", @UI_TEXT = \"\"Directory Info\"\"];"
               + " FROM \"DIV\" JOIN TO MYDIV SELECT \"groupbox\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " FROM \"DIRLABEL\" JOIN TO DIV SELECT \"label\" AS CONTROLNAME, \"child\" as PARENTRELATION FROM \"dirLblID\"  JOIN TO DIRLABEL SELECT \"text\" AS ATTRIBUTETYPE,\"attribute\" AS PARENTRELATION, \"" + folderPath + "\" AS ATTRIBUTEVALUE  FROM \"PATHID\" JOIN TO DIRLABEL SELECT \"idname\" AS ATTRIBUTETYPE, \"attribute\" AS PARENTRELATION, \"currDirectory\" as ATTRIBUTEVALUE FROM \"hidethis\" JOIN TO DIRLABEL SELECT \"cssdisplay\" AS ATTRIBUTETYPE, \"none\" AS ATTRIBUTEVALUE, \"attribute\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Folder Name : " + fol.Name + "\"\"]; FROM \"NameBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Folder Path : " + fol.FullName.Replace(rootPath, "~") + "\"\"]; FROM \"PathBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"File Count : " + fol.GetFiles().Length.ToString() + "\"\"]; FROM \"ExtBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Folder Size : " + fol.GetFiles().Sum(fil => fil.Length).ToString() + " bytes \"\"]; FROM \"SizeBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Creation Date : " + fol.CreationTime.ToShortDateString() + "\"\"]; FROM \"DateBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + " SNIPPET UI_LABEL[@PARENT_JOIN = \"DIV\", @UI_FONTSIZE = \"20\", @UI_TEXT = \"\"Child Directories : " + fol.GetDirectories().Length.ToString() + "\"\"]; FROM \"CHILDDirBreak\" JOIN TO DIV SELECT \"breakline\" AS CONTROLNAME,\"child\" AS PARENTRELATION "
               + "  FROM \"upfile\" JOIN TO DIV SELECT \"fileupload\" AS CONTROLNAME,\"child\" AS PARENTRELATION "; ;
            sectionQry = new UIWebSection(fileQuery).AsJson;
            return "";
        }
        public async Task UploadFilesAsync(IList<IFormFile> files, string currPath)
        {
            foreach (IFormFile source in files)
            {
                string filename = ContentDispositionHeaderValue.Parse(source.ContentDisposition).FileName.Trim('"');
                using (FileStream output = System.IO.File.Create(currPath + Path.DirectorySeparatorChar + source.FileName))
                    await source.CopyToAsync(output);
            }
        }
        //*Create a JSON Segment for a list of files.
        public string FileSegment(List<string> fileName)
        {
            System.IO.DirectoryInfo dirInfo = new DirectoryInfo(rootPath);
            var pairs = new List<List<KeyValuePair<string, string>>>();
            System.IO.FileInfo[] foundFiles = dirInfo.GetFiles("*.*", SearchOption.AllDirectories).Where(fil => fileName.Contains(fil.Name)).ToArray();
            foreach (System.IO.FileInfo fi in foundFiles)
            {
                var fileSeg = new List<KeyValuePair<string, string>>();
                fileSeg.Add(new KeyValuePair<string, string>("FILENAME", fi.Name));
                fileSeg.Add(new KeyValuePair<string, string>("FULLPATH", fi.FullName.Replace(rootPath, "~")));
                fileSeg.Add(new KeyValuePair<string, string>("EXTENSION", fi.Extension));
                fileSeg.Add(new KeyValuePair<string, string>("CREATIONTIME", fi.CreationTime.ToShortDateString()));
                fileSeg.Add(new KeyValuePair<string, string>("FILESIZE", fi.Length.ToString() + " bytes"));
                pairs.Add(fileSeg);
            }
            return "{" + ToJson(pairs, "FILES", true) + "}";
        }
        public string ToJson(List<List<KeyValuePair<string, string>>> pairs, string arrayName, bool close)
        {
            string j = "\"" + arrayName + "\": [";
            foreach (var jsonSeg in pairs)
            {
                j += "{";
                foreach (var pair in jsonSeg)
                {
                    j += "\"" + pair.Key + "\" : \"" + pair.Value.Replace("\"", "\\\"").Replace("\\", "\\\\") + "\",";
                }
                j = j.Substring(0, j.Length - 1);
                j += "},";
            }
            j = j.Substring(0, j.Length - 1);
            if (close) 
            { j += "]"; }
            else
            {
                j = j.Substring(0,j.Length - 1);
            }
            return j;
        }
        //*Create a JSON Segment for a list of Directories including their child files.
        public string DirectorySegment(List<DirectoryInfo> Dirs)
        {
            string finalJson = "{ ";
            List<List<KeyValuePair<string, string>>> allPairs = new List<List<KeyValuePair<string, string>>>();
            foreach (var thsDirInfo in Dirs)
            {
                var dirSeg = new List<KeyValuePair<string, string>>();
                dirSeg.Add(new KeyValuePair<string, string>("FULLPATH", thsDirInfo.FullName.Replace(rootPath, "~")));
                dirSeg.Add(new KeyValuePair<string, string>("FOLDERNAME", thsDirInfo.Name));
                dirSeg.Add(new KeyValuePair<string, string>("CREATIONTIME", thsDirInfo.CreationTime.ToString()));
                dirSeg.Add(new KeyValuePair<string, string>("FILECOUNT", thsDirInfo.GetFiles().Length.ToString()));
                dirSeg.Add(new KeyValuePair<string, string>("CHILDDIRECTORYCOUNT", thsDirInfo.GetDirectories().Length.ToString()));
                dirSeg.Add(new KeyValuePair<string, string>("TOTALSIZE", thsDirInfo.GetFiles().Sum(fil => fil.Length).ToString() + " bytes"));
                //allPairs.Add(dirSeg);
                var thsDir = new List<List<KeyValuePair<string, string>>>();
                thsDir.Add(dirSeg);
                finalJson += ToJson(thsDir, "DIRECTORIES", false) +",";
                finalJson += ToJson(ChildFiles(thsDirInfo.GetFiles().ToList()), "FILES", true);
                finalJson += "}]";
            }
            return finalJson + " }";
        }
        List<List<KeyValuePair<string, string>>> ChildFiles(List<FileInfo> files)
        {
            var pairs = new List<List<KeyValuePair<string, string>>>();
            foreach (System.IO.FileInfo fi in files)
            {
                var fileSeg = new List<KeyValuePair<string, string>>();
                fileSeg.Add(new KeyValuePair<string, string>("FILENAME", fi.Name));
                fileSeg.Add(new KeyValuePair<string, string>("FULLPATH", fi.FullName.Replace(rootPath, "~")));
                fileSeg.Add(new KeyValuePair<string, string>("EXTENSION", fi.Extension));
                fileSeg.Add(new KeyValuePair<string, string>("CREATIONTIME", fi.CreationTime.ToShortDateString()));
                fileSeg.Add(new KeyValuePair<string, string>("FILESIZE", fi.Length.ToString() + " bytes"));
                pairs.Add(fileSeg);
            }
            return pairs;
        }
    }
}
