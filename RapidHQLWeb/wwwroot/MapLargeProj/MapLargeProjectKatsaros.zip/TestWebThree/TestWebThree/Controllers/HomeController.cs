﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using rogueCore.rogueUIV3.web;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TestWebThree.Models;

namespace TestWebThree.Controllers
{
    public class HomeController : Controller
    {
        string rootPath { get { return _webHostEnvironment.WebRootPath + Path.DirectorySeparatorChar + baseFolderName; } }
        string tempPath { get { return _webHostEnvironment.WebRootPath + "\\temp\\"; } }
        const string baseFolderName = "FileRoot";        
        DirectoryModel myModel;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public HomeController(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
            myModel = new DirectoryModel(rootPath);
        }
        [HttpGet]
        public IActionResult Index(string id)
        {
            return View();
        }
        public JsonResult ClickEvent(string clickParam)
        {
            myModel.RunClickEvent(clickParam);
            return GetSection("");
        }
        [HttpPost]
        public async Task<JsonResult> UploadFilesAsync(IList<IFormFile> files,string currPath)
        {
            await myModel.UploadFilesAsync(files, currPath);
            return GetSection("");
        }
        [HttpGet]
        public ActionResult Export(string filePath)
        {
            var fil = new FileInfo(filePath);            
            string newPath = tempPath + fil.Name;
            if (!System.IO.File.Exists(newPath))
            {
                System.IO.File.Copy(filePath, newPath);
            }            
            var errorMessage = "Download Error!";
            return Json(new { fileName = fil.Name, errorMessage });
        }
        [HttpGet]
        public ActionResult Download(string fileName)
        {
            string fullPath = tempPath + fileName;
            byte[] fileByteArray = System.IO.File.ReadAllBytes(fullPath);
            System.IO.File.Delete(fullPath);
            return File(fileByteArray, "text/plain", fileName);
        }
        [HttpGet]
        public JsonResult GetSection(string urlPath)
        {
            if(urlPath != null && urlPath != "")
            {
                if(urlPath.StartsWith("/") || urlPath.StartsWith("\\")) { urlPath = urlPath.Substring(1, urlPath.Length - 1); }
                myModel = new DirectoryModel(rootPath, rootPath + Path.DirectorySeparatorChar + urlPath);
            }
            string myJson = new UIWebSection(myModel.directoryQuery).AsJson;
            myJson = "{ \"dirMenu\": " + myJson + ", ";
            myJson += "\"fileUpload\" : " + myModel.sectionQry;
            myJson += " }";
            return Json(myJson);
        }        
        [Route("/QueryFolder")]
        [HttpGet]
        public string QueryFolder(string folderName)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(rootPath);
            var pairs = new List<List<KeyValuePair<string, string>>>();
            DirectoryInfo[] foundFolders = dirInfo.GetDirectories(folderName, SearchOption.AllDirectories);
            return myModel.DirectorySegment(foundFolders.ToList());
        }
        [Route("/QueryPath")]
        [HttpGet]
        public string QueryPath(string path)
        {
            if (!path.StartsWith("/"))
            {
                path = "/" + path;
            }
            DirectoryInfo dirInfo = new DirectoryInfo(rootPath + path);
            var lst = new List<DirectoryInfo>();
            lst.Add(dirInfo);
            return myModel.DirectorySegment(lst);
        }
        [Route("/QueryFile")]
        [HttpGet]
        public string QueryFile(List<string> fileName)
        {
            return myModel.FileSegment(fileName);
        }
    }
}
